#!/usr/bin/env bash
set -euo pipefail

if [ "$(id -u)" -ne 0 ]; then
  echo "Run as root: sudo bash install-ubuntu.sh"
  exit 1
fi

SOURCE_DIR="$(cd "$(dirname "$0")" && pwd)"
TARGET=/opt/readori-edge-tts

apt-get update
apt-get install -y --no-install-recommends python3 python3-venv ca-certificates

if ! id -u readori-tts >/dev/null 2>&1; then
  useradd --system --home-dir "$TARGET" --shell /usr/sbin/nologin readori-tts
fi

mkdir -p "$TARGET"
cp "$SOURCE_DIR/server.py" "$SOURCE_DIR/requirements.txt" "$TARGET/"
python3 -m venv "$TARGET/.venv"
"$TARGET/.venv/bin/pip" install --no-cache-dir --upgrade pip
"$TARGET/.venv/bin/pip" install --no-cache-dir -r "$TARGET/requirements.txt"
chown -R readori-tts:readori-tts "$TARGET"
chmod 0750 "$TARGET"

cp "$SOURCE_DIR/readori-edge-tts.service" /etc/systemd/system/readori-edge-tts.service
if [ ! -f /etc/readori-edge-tts.env ]; then
  cp "$SOURCE_DIR/readori-edge-tts.env.example" /etc/readori-edge-tts.env
  chmod 0600 /etc/readori-edge-tts.env
  echo "Created /etc/readori-edge-tts.env. Set ORACLE_EDGE_TTS_TOKEN before starting."
fi

systemctl daemon-reload
systemctl enable readori-edge-tts.service

echo "Installed. Next: edit /etc/readori-edge-tts.env, then run:"
echo "  systemctl restart readori-edge-tts"
echo "  systemctl status readori-edge-tts --no-pager"
echo "Expose it only through HTTPS (Caddy/nginx/Cloudflare Tunnel). Do not open port 8788 publicly."
