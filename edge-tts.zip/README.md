# Readori Oracle Edge-TTS experimental fallback

This is a deliberately small experimental TTS gateway for a low-resource Oracle Cloud VM. It does **not** run a neural speech model locally. The Python service wraps the third-party `edge-tts` package, which contacts Microsoft Edge's online read-aloud service.

## Product boundary

- Keep this provider disabled by default: `AI_TTS_ORACLE_EDGE_ENABLED=false`.
- It is an **experimental / disaster-recovery** provider, not the commercial Microsoft Azure Speech API.
- Readori's normal production path remains Cloudflare Workers AI; Azure Speech is the preferred official Microsoft provider when enabled.
- No source text is intentionally written to disk, D1, or application logs.
- `/v1/tts` requires a long bearer token. `/health` contains no secret and performs no synthesis.
- Python binds to `127.0.0.1:8788` by default. Do not expose port 8788 in OCI Security Lists / NSGs.
- Default concurrency is 2. The systemd unit caps the process at 650 MB RAM and 80% CPU.
- Individual Edge-TTS synthesis is capped at 12 seconds so the Cloudflare router can fail over before the iOS request times out.

## Files

```text
server.py
requirements.txt
readori-edge-tts.env.example
readori-edge-tts.service
install-ubuntu.sh
Caddyfile.example
```

## Install on Ubuntu

```bash
cd /path/to/oracle-edge-tts
sudo bash install-ubuntu.sh

openssl rand -hex 32
sudo nano /etc/readori-edge-tts.env
# Put the generated value in ORACLE_EDGE_TTS_TOKEN.

sudo systemctl restart readori-edge-tts
sudo systemctl status readori-edge-tts --no-pager
curl http://127.0.0.1:8788/health
```

Expected health response is similar to:

```json
{
  "ok": true,
  "service": "readori-oracle-edge-tts",
  "provider": "edge-tts",
  "experimental": true,
  "maxConcurrency": 2
}
```

## HTTPS exposure

Use **one** of these patterns:

1. Cloudflare Tunnel → `127.0.0.1:8788` (preferred if you do not want inbound VM ports).
2. Caddy/nginx on the VM → `127.0.0.1:8788`.

For Caddy, copy and edit `Caddyfile.example`. Only 443/HTTPS should be exposed publicly. The bearer token remains required even when the endpoint is behind HTTPS.

Test from outside the VM:

```bash
curl https://tts.example.com/health

curl -o test.mp3 https://tts.example.com/v1/tts \
  -H "Authorization: Bearer YOUR_LONG_RANDOM_TOKEN" \
  -H "Content-Type: application/json" \
  --data '{"text":"你好，这是 Readori 备用朗读测试。","locale":"zh-CN","speed":1.0}'
```

## Cloudflare / GitHub configuration

Do **not** put the token in Repository Variables.

GitHub Repository **Secret**:

```text
ORACLE_EDGE_TTS_TOKEN=<same long token used by the Oracle service>
```

GitHub Repository **Variables**:

```text
AI_TTS_ORACLE_EDGE_ENABLED=true
ORACLE_EDGE_TTS_URL=https://tts.example.com
```

Commit/push or manually run the existing deployment workflow. CI renders `wrangler.toml` and uploads the secret with Wrangler. The iOS app never receives the Oracle URL or bearer token.

To disable immediately without deleting anything:

```text
AI_TTS_ORACLE_EDGE_ENABLED=false
```

Redeploy the Worker. No iOS release is required.

## Optional voice overrides on Oracle

Edit `/etc/readori-edge-tts.env`:

```text
EDGE_VOICE_ZH_CN=zh-CN-XiaoxiaoNeural
EDGE_VOICE_ZH_TW=zh-TW-HsiaoChenNeural
EDGE_VOICE_EN_US=en-US-AvaMultilingualNeural
EDGE_VOICE_JA_JP=ja-JP-NanamiNeural
EDGE_VOICE_KO_KR=ko-KR-SunHiNeural
EDGE_VOICE_FR_FR=fr-FR-DeniseNeural
EDGE_VOICE_ES_ES=es-ES-ElviraNeural
```

Then:

```bash
sudo systemctl restart readori-edge-tts
```

Because Edge-TTS is not the Azure Speech commercial API, verify voice availability during testing whenever the third-party package or Microsoft Edge service changes.

## Troubleshooting

```bash
journalctl -u readori-edge-tts -n 100 --no-pager
systemctl status readori-edge-tts --no-pager
curl http://127.0.0.1:8788/health
```

The service intentionally suppresses access logs and upstream exception text. If synthesis fails, logs contain only a stable exception class so book text is not leaked through diagnostics.
