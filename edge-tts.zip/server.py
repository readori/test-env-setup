#!/usr/bin/env python3
"""Readori Oracle Edge-TTS experimental fallback gateway.

This service does NOT run a speech model locally. It is a small authenticated
HTTP proxy around the third-party `edge-tts` Python package, which talks to
Microsoft Edge's online read-aloud service. Keep it disabled in the production
router unless you deliberately accept that experimental dependency.
"""

from __future__ import annotations

import asyncio
import hmac
import io
import json
import os
from typing import Final

import edge_tts
from aiohttp import web

MAX_TEXT_CHARS: Final = 4_000
MAX_AUDIO_BYTES: Final = 8 * 1024 * 1024
REQUEST_TIMEOUT_SECONDS: Final = 12

DEFAULT_VOICES: Final = {
    "zh-CN": "zh-CN-XiaoxiaoNeural",
    "zh-TW": "zh-TW-HsiaoChenNeural",
    "en-US": "en-US-AvaMultilingualNeural",
    "ja-JP": "ja-JP-NanamiNeural",
    "ko-KR": "ko-KR-SunHiNeural",
    "fr-FR": "fr-FR-DeniseNeural",
    "es-ES": "es-ES-ElviraNeural",
}


def env_int(name: str, default: int, minimum: int, maximum: int) -> int:
    try:
        value = int(os.getenv(name, str(default)))
    except ValueError:
        value = default
    return max(minimum, min(maximum, value))


CONCURRENCY = env_int("EDGE_TTS_MAX_CONCURRENCY", 2, 1, 4)
SEMAPHORE = asyncio.Semaphore(CONCURRENCY)


def json_error(message: str, status: int, code: str) -> web.Response:
    return web.json_response(
        {"ok": False, "error": message, "code": code},
        status=status,
        headers={"Cache-Control": "no-store"},
    )


def authorized(request: web.Request) -> bool:
    expected = os.getenv("ORACLE_EDGE_TTS_TOKEN", "").strip()
    if not expected:
        return False
    header = request.headers.get("Authorization", "")
    if not header.startswith("Bearer "):
        return False
    supplied = header.removeprefix("Bearer ").strip()
    return bool(supplied) and hmac.compare_digest(supplied, expected)


def normalize_locale(value: object) -> str:
    raw = str(value or "en-US").replace("_", "-").lower()
    if raw.startswith(("zh-tw", "zh-hk", "zh-hant")):
        return "zh-TW"
    if raw.startswith("zh"):
        return "zh-CN"
    if raw.startswith("ja"):
        return "ja-JP"
    if raw.startswith("ko"):
        return "ko-KR"
    if raw.startswith("fr"):
        return "fr-FR"
    if raw.startswith("es"):
        return "es-ES"
    return "en-US"


def voice_for_locale(locale: str) -> str:
    env_name = f"EDGE_VOICE_{locale.replace('-', '_').upper()}"
    configured = os.getenv(env_name, "").strip()
    return configured or DEFAULT_VOICES.get(locale, DEFAULT_VOICES["en-US"])


def edge_rate(speed_value: object) -> str:
    try:
        speed = float(speed_value)
    except (TypeError, ValueError):
        speed = 1.0
    speed = max(0.5, min(2.0, speed))
    percent = round((speed - 1.0) * 100)
    return f"{percent:+d}%"


async def health(_: web.Request) -> web.Response:
    return web.json_response(
        {
            "ok": True,
            "service": "readori-oracle-edge-tts",
            "provider": "edge-tts",
            "experimental": True,
            "maxConcurrency": CONCURRENCY,
        },
        headers={"Cache-Control": "no-store"},
    )


async def synthesize(request: web.Request) -> web.Response:
    if not authorized(request):
        return json_error("Unauthorized", 401, "UNAUTHORIZED")

    if request.content_length and request.content_length > 64 * 1024:
        return json_error("Request body too large", 413, "REQUEST_TOO_LARGE")

    try:
        payload = await request.json(loads=json.loads)
    except Exception:
        return json_error("Invalid JSON", 400, "INVALID_JSON")

    text = str(payload.get("text") or "").strip()
    if not text:
        return json_error("text is required", 400, "TEXT_REQUIRED")
    if len(text) > MAX_TEXT_CHARS:
        return json_error("text is too long", 400, "TEXT_TOO_LONG")

    locale = normalize_locale(payload.get("locale"))
    voice = voice_for_locale(locale)
    rate = edge_rate(payload.get("speed"))

    try:
        async with SEMAPHORE:
            audio = await asyncio.wait_for(
                synthesize_edge_audio(text=text, voice=voice, rate=rate),
                timeout=REQUEST_TIMEOUT_SECONDS,
            )
    except asyncio.TimeoutError:
        return json_error("Speech service timed out", 504, "EDGE_TTS_TIMEOUT")
    except Exception as exc:
        # Do not log or return upstream exception text; some exceptions may carry
        # request details. Stable class name is enough for server diagnostics.
        print(f"edge-tts synthesis failed: {type(exc).__name__}", flush=True)
        return json_error("Speech service unavailable", 502, "EDGE_TTS_FAILED")

    if not audio:
        return json_error("Empty speech audio", 502, "EMPTY_AUDIO")

    return web.Response(
        body=audio,
        content_type="audio/mpeg",
        headers={
            "Cache-Control": "private, no-store, max-age=0",
            "X-Content-Type-Options": "nosniff",
            "X-Readori-TTS-Provider": "oracle-edge",
            "X-Readori-AI-Generated": "true",
        },
    )


async def synthesize_edge_audio(*, text: str, voice: str, rate: str) -> bytes:
    communicator = edge_tts.Communicate(
        text,
        voice,
        rate=rate,
        volume="+0%",
        pitch="+0Hz",
    )
    buffer = io.BytesIO()
    async for chunk in communicator.stream():
        if chunk.get("type") != "audio":
            continue
        data = chunk.get("data") or b""
        if buffer.tell() + len(data) > MAX_AUDIO_BYTES:
            raise RuntimeError("audio_limit")
        buffer.write(data)
    return buffer.getvalue()


def create_app() -> web.Application:
    app = web.Application(client_max_size=64 * 1024)
    app.router.add_get("/health", health)
    app.router.add_post("/v1/tts", synthesize)
    return app


if __name__ == "__main__":
    if not os.getenv("ORACLE_EDGE_TTS_TOKEN", "").strip():
        raise SystemExit("ORACLE_EDGE_TTS_TOKEN must be configured")
    host = os.getenv("EDGE_TTS_BIND", "127.0.0.1")
    port = env_int("EDGE_TTS_PORT", 8788, 1024, 65535)
    web.run_app(create_app(), host=host, port=port, access_log=None)
